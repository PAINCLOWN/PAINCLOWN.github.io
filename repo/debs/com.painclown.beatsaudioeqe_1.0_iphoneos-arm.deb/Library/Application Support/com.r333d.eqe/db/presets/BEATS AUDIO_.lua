return {
    {
        name = "preamp",
        gain = -0.0,
    },
    {
        name = "eq",
        frequency = 30.0,
        Q = 0.287878,
        gain = -1.685862,
    },
    {
        name = "eq",
        frequency = 65.0,
        Q = 1.290876,
        gain = 4.645199,
    },
    {
        name = "eq",
        frequency = 180.0,
        Q = 0.0,
        gain = 0.398563,
    },
    {
        name = "eq",
        frequency = 317.491974,
        Q = 0.071824,
        gain = 0.311344,
    },
    {
        name = "eq",
        frequency = 425.869965,
        Q = 1e-06,
        gain = -0.005039,
    },
    {
        name = "eq",
        frequency = 1007.278442,
        Q = 0.352314,
        gain = -0.406417,
    },
    {
        name = "eq",
        frequency = 2000.0,
        Q = 3.8e-05,
        gain = -0.441313,
    },
    {
        name = "eq",
        frequency = 6000,
        Q = 1.483396,
        gain = 0.0,
    },
    {
        name = "eq",
        frequency = 10.0,
        Q = 2,
        gain = 0.0,
    },
    {
        name = "eq",
        frequency = 10000.0,
        Q = 1e-06,
        gain = 0.264116,
    },
    {
        name = "lowpass",
        frequency = 19146.626953,
        Q = 1.515835,
    },
    {
        name = "eq",
        frequency = 20,
        Q = 2,
        gain = 0,
    },
}